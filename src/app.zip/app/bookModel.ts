export class book {
    
    name: string;
    email: string;
    author: string;
    price: string;

}