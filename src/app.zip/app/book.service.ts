
import { Injectable } from '@angular/core';
import { book} from './bookModel';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http:HttpClient) { }
   
  addUser(_book : book)
   {
    this.http.post('https://new-project-9e859.firebaseio.com//user.json',_book).subscribe(
    response =>  {console.log(response)}
    ),
    error =>{
     console.log(error);
   }

}

}
