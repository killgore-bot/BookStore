import { Component, OnInit, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent  { 

  @ViewChild('f',{static : true}) signupForm:NgForm;
book ={
  name:'',
  email:'',
  author:'',
  price: '',
};
  
  constructor() { }

  onSubmit( )
{
  this.book.name = this.signupForm.value.Name;
  this.book.email = this.signupForm.value.Email;
  this.book.author = this.signupForm.value.Author;
  this.book.price = this.signupForm.value.Price;


  
  //this._app.addUser(this.book);

  console.log(this.book);

  
     
    };

};

  //ngOnInit() { };


